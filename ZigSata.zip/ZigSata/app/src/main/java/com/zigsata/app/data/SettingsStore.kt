package com.zigsata.app.data

import android.content.Context

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("zigsata_settings", Context.MODE_PRIVATE)

    var serverUrl: String
        get() = prefs.getString(KEY_SERVER_URL, "") ?: ""
        set(value) = prefs.edit().putString(KEY_SERVER_URL, value.trim()).apply()

    var timeoutSeconds: Int
        get() = prefs.getInt(KEY_TIMEOUT, 20)
        set(value) = prefs.edit().putInt(KEY_TIMEOUT, value).apply()

    companion object {
        private const val KEY_SERVER_URL = "server_url"
        private const val KEY_TIMEOUT = "timeout_seconds"
    }
}
