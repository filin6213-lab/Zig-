# Add project specific ProGuard rules here.
# Zig Sata does not use reflection-heavy libraries, so default rules are sufficient.
