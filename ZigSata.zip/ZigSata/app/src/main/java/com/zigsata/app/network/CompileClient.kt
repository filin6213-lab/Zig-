package com.zigsata.app.network

import android.content.Context
import com.zigsata.app.model.CompileDiagnostic
import com.zigsata.app.model.CompileError
import com.zigsata.app.model.CompileResult
import com.zigsata.app.util.ErrorParser
import com.zigsata.app.util.NetworkUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.SocketTimeoutException
import java.util.concurrent.TimeUnit

/**
 * Talks to a Zig Sata compile server (see /server in this repository for a
 * reference implementation). The server contract:
 *
 * POST {serverUrl}/compile
 * body: { "main": "main.zig", "files": [ { "name": "main.zig", "content": "..." }, ... ] }
 *
 * response 200: {
 *   "success": true|false,
 *   "exitCode": 0,
 *   "stdout": "...",
 *   "stderr": "..."
 * }
 */
class CompileClient(private val context: Context) {

    sealed class Outcome {
        data class Success(val result: CompileResult) : Outcome()
        data class Failure(val error: CompileError) : Outcome()
    }

    suspend fun compile(
        serverUrl: String,
        timeoutSeconds: Int,
        mainFile: String,
        files: List<Pair<String, String>>
    ): Outcome = withContext(Dispatchers.IO) {
        if (serverUrl.isBlank()) return@withContext Outcome.Failure(CompileError.NoServerConfigured)
        if (!NetworkUtils.isOnline(context)) return@withContext Outcome.Failure(CompileError.NoInternet)

        val client = OkHttpClient.Builder()
            .connectTimeout(timeoutSeconds.toLong(), TimeUnit.SECONDS)
            .readTimeout(timeoutSeconds.toLong(), TimeUnit.SECONDS)
            .writeTimeout(timeoutSeconds.toLong(), TimeUnit.SECONDS)
            .build()

        val payload = JSONObject().apply {
            put("main", mainFile)
            put("files", JSONArray().apply {
                files.forEach { (name, content) ->
                    put(JSONObject().apply {
                        put("name", name)
                        put("content", content)
                    })
                }
            })
        }

        val url = serverUrl.trimEnd('/') + "/compile"
        val body = payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
        val request = Request.Builder().url(url).post(body).build()

        try {
            client.newCall(request).execute().use { response ->
                val bodyString = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext Outcome.Failure(
                        CompileError.Other("Server returned HTTP ${response.code}: ${bodyString.take(300)}")
                    )
                }
                return@withContext try {
                    val json = JSONObject(bodyString)
                    val stdout = json.optString("stdout", "")
                    val stderr = json.optString("stderr", "")
                    val diagnostics: List<CompileDiagnostic> = ErrorParser.parse(stderr).ifEmpty { ErrorParser.parse(stdout) }
                    Outcome.Success(
                        CompileResult(
                            success = json.optBoolean("success", json.optInt("exitCode", -1) == 0),
                            exitCode = if (json.has("exitCode")) json.optInt("exitCode") else null,
                            stdout = stdout,
                            stderr = stderr,
                            diagnostics = diagnostics
                        )
                    )
                } catch (e: Exception) {
                    Outcome.Failure(CompileError.InvalidResponse(e.message ?: "malformed JSON"))
                }
            }
        } catch (e: SocketTimeoutException) {
            Outcome.Failure(CompileError.Timeout)
        } catch (e: IOException) {
            Outcome.Failure(CompileError.ServerUnreachable)
        }
    }
}
