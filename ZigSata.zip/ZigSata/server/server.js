'use strict';

/**
 * Zig Sata reference compile server.
 *
 * This is a minimal, self-contained example of the server contract the
 * Android app expects. It is meant as a starting point for self-hosting,
 * NOT a hardened production service. If you expose this publicly, run it
 * inside an isolated container/VM with no outbound network access, strict
 * CPU/memory/time limits, and treat every request as untrusted code
 * execution (because it is).
 *
 * Contract:
 *   POST /compile
 *   body: { "main": "main.zig", "files": [ { "name": "main.zig", "content": "..." }, ... ] }
 *   response: { "success": bool, "exitCode": number|null, "stdout": string, "stderr": string }
 *
 *   GET /health -> { "status": "ok", "zigVersion": "..." }
 */

const express = require('express');
const { execFile } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');

const PORT = process.env.PORT || 3000;
const ZIG_BIN = process.env.ZIG_BIN || 'zig';
const COMPILE_TIMEOUT_MS = parseInt(process.env.COMPILE_TIMEOUT_MS || '20000', 10);
const MAX_FILES = 40;
const MAX_TOTAL_BYTES = 2 * 1024 * 1024; // 2 MB total source per request

const app = express();
app.use(express.json({ limit: '4mb' }));

app.get('/health', (req, res) => {
  execFile(ZIG_BIN, ['version'], { timeout: 5000 }, (err, stdout) => {
    if (err) {
      return res.status(500).json({ status: 'error', message: 'zig binary not found or not executable' });
    }
    res.json({ status: 'ok', zigVersion: stdout.trim() });
  });
});

app.post('/compile', async (req, res) => {
  const body = req.body || {};
  const files = Array.isArray(body.files) ? body.files : [];
  const mainFile = typeof body.main === 'string' && body.main.trim() ? body.main.trim() : 'main.zig';

  const validationError = validateRequest(files, mainFile);
  if (validationError) {
    return res.status(400).json({ success: false, exitCode: null, stdout: '', stderr: validationError });
  }

  const workDir = path.join(os.tmpdir(), 'zigsata-' + crypto.randomBytes(8).toString('hex'));

  try {
    fs.mkdirSync(workDir, { recursive: true });
    for (const file of files) {
      const safeName = sanitizeFileName(file.name);
      if (!safeName) continue;
      fs.writeFileSync(path.join(workDir, safeName), String(file.content ?? ''), 'utf8');
    }

    const mainPath = path.join(workDir, sanitizeFileName(mainFile) || 'main.zig');
    if (!fs.existsSync(mainPath)) {
      cleanup(workDir);
      return res.status(400).json({
        success: false,
        exitCode: null,
        stdout: '',
        stderr: `Main file "${mainFile}" was not found among the uploaded files.`
      });
    }

    // `zig run` compiles and executes in one step, which matches what a
    // mobile IDE user expects from pressing "Run". For a build-only mode
    // you could swap this for `zig build-exe`.
    execFile(
      ZIG_BIN,
      ['run', mainPath, '--cache-dir', path.join(workDir, '.zig-cache')],
      { cwd: workDir, timeout: COMPILE_TIMEOUT_MS, maxBuffer: 10 * 1024 * 1024 },
      (error, stdout, stderr) => {
        cleanup(workDir);
        if (error && error.killed) {
          return res.status(200).json({
            success: false,
            exitCode: null,
            stdout: stdout || '',
            stderr: (stderr || '') + '\n[zig-sata] Process timed out after ' + COMPILE_TIMEOUT_MS + 'ms.'
          });
        }
        const exitCode = error ? (typeof error.code === 'number' ? error.code : 1) : 0;
        res.status(200).json({
          success: exitCode === 0,
          exitCode,
          stdout: stdout || '',
          stderr: stderr || ''
        });
      }
    );
  } catch (err) {
    cleanup(workDir);
    res.status(500).json({ success: false, exitCode: null, stdout: '', stderr: 'Server error: ' + err.message });
  }
});

function validateRequest(files, mainFile) {
  if (files.length === 0) return 'No files were provided.';
  if (files.length > MAX_FILES) return `Too many files (max ${MAX_FILES}).`;
  let totalBytes = 0;
  for (const file of files) {
    if (typeof file.name !== 'string' || !file.name.endsWith('.zig')) {
      return `Invalid file name: ${file.name}`;
    }
    totalBytes += Buffer.byteLength(String(file.content ?? ''), 'utf8');
  }
  if (totalBytes > MAX_TOTAL_BYTES) return 'Total source size exceeds the limit.';
  if (!mainFile.endsWith('.zig')) return 'Main file must end with .zig';
  return null;
}

/** Strips directory separators and traversal sequences; only allows a flat file name. */
function sanitizeFileName(name) {
  if (typeof name !== 'string') return null;
  const base = path.basename(name);
  if (!base.endsWith('.zig')) return null;
  if (base.includes('..')) return null;
  return base;
}

function cleanup(dir) {
  fs.rm(dir, { recursive: true, force: true }, () => {});
}

app.listen(PORT, () => {
  console.log(`Zig Sata compile server listening on port ${PORT}`);
});
