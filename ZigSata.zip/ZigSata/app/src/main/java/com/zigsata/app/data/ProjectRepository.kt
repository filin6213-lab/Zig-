package com.zigsata.app.data

import android.content.Context
import com.zigsata.app.model.Project
import com.zigsata.app.util.ZipUtils
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID

/**
 * All persistence for Zig Sata lives under the app's private files directory:
 *
 *   files/projects/<projectId>/project.json
 *   files/projects/<projectId>/*.zig
 *
 * No external storage permission is required and everything survives app
 * restarts and updates. Import/export uses the Storage Access Framework so
 * the user can move projects in and out via a system file picker.
 */
class ProjectRepository(context: Context) {

    private val projectsRoot: File = File(context.filesDir, "projects").apply { mkdirs() }

    // ---------- Project listing / CRUD ----------

    fun listProjects(): List<Project> {
        val dirs = projectsRoot.listFiles { f -> f.isDirectory } ?: emptyArray()
        return dirs.mapNotNull { dir -> readMetadata(dir) }.sortedByDescending { it.updatedAt }
    }

    fun getProjectDir(projectId: String): File = File(projectsRoot, projectId)

    fun createProject(name: String): Project {
        val id = UUID.randomUUID().toString()
        val dir = File(projectsRoot, id).apply { mkdirs() }
        val now = System.currentTimeMillis()
        val project = Project(id = id, name = name.ifBlank { "untitled" }, mainFile = "main.zig", createdAt = now, updatedAt = now)
        writeMetadata(project)
        val mainFile = File(dir, "main.zig")
        mainFile.writeText(DEFAULT_MAIN_ZIG)
        return project
    }

    fun deleteProject(projectId: String) {
        getProjectDir(projectId).deleteRecursively()
    }

    fun renameProject(projectId: String, newName: String) {
        val project = readMetadata(getProjectDir(projectId)) ?: return
        project.name = newName.ifBlank { project.name }
        project.updatedAt = System.currentTimeMillis()
        writeMetadata(project)
    }

    fun touch(projectId: String) {
        val project = readMetadata(getProjectDir(projectId)) ?: return
        project.updatedAt = System.currentTimeMillis()
        writeMetadata(project)
    }

    fun getProject(projectId: String): Project? = readMetadata(getProjectDir(projectId))

    private fun readMetadata(dir: File): Project? {
        val metaFile = File(dir, "project.json")
        if (!metaFile.exists()) return null
        return try {
            Project.fromJson(JSONObject(metaFile.readText()))
        } catch (e: Exception) {
            null
        }
    }

    private fun writeMetadata(project: Project) {
        val dir = getProjectDir(project.id)
        dir.mkdirs()
        File(dir, "project.json").writeText(project.toJson().toString())
    }

    fun setMainFile(projectId: String, fileName: String) {
        val project = readMetadata(getProjectDir(projectId)) ?: return
        project.mainFile = fileName
        writeMetadata(project)
    }

    // ---------- File listing / CRUD ----------

    /** Returns .zig file names (not full paths) sorted alphabetically, main file first. */
    fun listFiles(projectId: String): List<String> {
        val dir = getProjectDir(projectId)
        val project = readMetadata(dir)
        val names = (dir.listFiles { f -> f.isFile && f.name.endsWith(".zig") } ?: emptyArray())
            .map { it.name }.sorted()
        return if (project != null && names.contains(project.mainFile)) {
            listOf(project.mainFile) + names.filter { it != project.mainFile }
        } else names
    }

    fun readFile(projectId: String, fileName: String): String {
        val file = File(getProjectDir(projectId), fileName)
        if (!file.exists()) throw IOException("File not found: $fileName")
        return file.readText()
    }

    fun writeFile(projectId: String, fileName: String, content: String) {
        val file = File(getProjectDir(projectId), fileName)
        file.parentFile?.mkdirs()
        file.writeText(content)
        touch(projectId)
    }

    fun createFile(projectId: String, fileName: String): String {
        val safeName = if (fileName.endsWith(".zig")) fileName else "$fileName.zig"
        val file = File(getProjectDir(projectId), safeName)
        if (file.exists()) throw IOException("A file named $safeName already exists")
        file.writeText("")
        touch(projectId)
        return safeName
    }

    fun deleteFile(projectId: String, fileName: String) {
        File(getProjectDir(projectId), fileName).delete()
        touch(projectId)
    }

    fun renameFile(projectId: String, oldName: String, newName: String): String {
        val safeName = if (newName.endsWith(".zig")) newName else "$newName.zig"
        val dir = getProjectDir(projectId)
        val src = File(dir, oldName)
        val dst = File(dir, safeName)
        if (dst.exists()) throw IOException("A file named $safeName already exists")
        if (!src.renameTo(dst)) throw IOException("Could not rename $oldName")
        val project = readMetadata(dir)
        if (project != null && project.mainFile == oldName) {
            project.mainFile = safeName
            writeMetadata(project)
        }
        touch(projectId)
        return safeName
    }

    // ---------- Import / export ----------

    fun exportProjectZip(projectId: String, out: OutputStream) {
        ZipUtils.zipDirectory(getProjectDir(projectId), out)
    }

    /** Imports a project from a zip previously produced by [exportProjectZip]. */
    fun importProjectZip(input: InputStream, fallbackName: String): Project {
        val id = UUID.randomUUID().toString()
        val dir = File(projectsRoot, id).apply { mkdirs() }
        ZipUtils.unzipToDirectory(input, dir)

        val metaFile = File(dir, "project.json")
        val project = if (metaFile.exists()) {
            try {
                val parsed = Project.fromJson(JSONObject(metaFile.readText()))
                parsed.copy(id = id, updatedAt = System.currentTimeMillis())
            } catch (e: Exception) {
                Project(id, fallbackName, "main.zig", System.currentTimeMillis(), System.currentTimeMillis())
            }
        } else {
            val firstZig = dir.listFiles { f -> f.name.endsWith(".zig") }?.firstOrNull()?.name ?: "main.zig"
            Project(id, fallbackName, firstZig, System.currentTimeMillis(), System.currentTimeMillis())
        }
        writeMetadata(project)
        if (dir.listFiles { f -> f.name.endsWith(".zig") }.isNullOrEmpty()) {
            File(dir, project.mainFile).writeText(DEFAULT_MAIN_ZIG)
        }
        return project
    }

    /** Imports a single loose .zig file into an existing project. */
    fun importFile(projectId: String, input: InputStream, suggestedName: String): String {
        var name = if (suggestedName.endsWith(".zig")) suggestedName else "$suggestedName.zig"
        val dir = getProjectDir(projectId)
        var target = File(dir, name)
        var counter = 1
        while (target.exists()) {
            val base = name.removeSuffix(".zig")
            name = "${base}_$counter.zig"
            target = File(dir, name)
            counter++
        }
        target.outputStream().use { output -> input.copyTo(output) }
        touch(projectId)
        return name
    }

    companion object {
        val DEFAULT_MAIN_ZIG = """
            const std = @import("std");

            pub fn main() !void {
                std.debug.print("Hello from Zig Sata!\n", .{});
            }
        """.trimIndent()
    }
}
