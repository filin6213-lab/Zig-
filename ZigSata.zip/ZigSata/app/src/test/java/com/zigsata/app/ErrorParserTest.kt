package com.zigsata.app

import com.zigsata.app.util.ErrorParser
import org.junit.Assert.assertEquals
import org.junit.Test

class ErrorParserTest {

    @Test
    fun `parses a single error line`() {
        val output = "main.zig:12:5: error: expected ';' after statement"
        val diagnostics = ErrorParser.parse(output)
        assertEquals(1, diagnostics.size)
        assertEquals("main.zig", diagnostics[0].file)
        assertEquals(12, diagnostics[0].line)
        assertEquals(5, diagnostics[0].column)
        assertEquals("error", diagnostics[0].severity)
        assertEquals("expected ';' after statement", diagnostics[0].message)
    }

    @Test
    fun `parses error and note together`() {
        val output = """
            main.zig:3:1: error: use of undeclared identifier 'foo'
            main.zig:1:1: note: did you mean 'main'?
        """.trimIndent()
        val diagnostics = ErrorParser.parse(output)
        assertEquals(2, diagnostics.size)
        assertEquals("error", diagnostics[0].severity)
        assertEquals("note", diagnostics[1].severity)
    }

    @Test
    fun `ignores unrelated lines`() {
        val output = "Hello from Zig Sata!\nsome random log line"
        val diagnostics = ErrorParser.parse(output)
        assertEquals(0, diagnostics.size)
    }

    @Test
    fun `empty input returns empty list`() {
        assertEquals(0, ErrorParser.parse("").size)
    }
}
