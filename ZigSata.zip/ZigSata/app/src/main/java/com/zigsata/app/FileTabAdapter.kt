package com.zigsata.app

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView

class FileTabAdapter(
    private val onSelect: (String) -> Unit
) : RecyclerView.Adapter<FileTabAdapter.VH>() {

    private val items = mutableListOf<String>()
    private var selected: String? = null

    fun submit(newItems: List<String>, selectedFile: String?) {
        items.clear()
        items.addAll(newItems)
        selected = selectedFile
        notifyDataSetChanged()
    }

    fun setSelected(fileName: String) {
        selected = fileName
        notifyDataSetChanged()
    }

    class VH(view: TextView) : RecyclerView.ViewHolder(view) {
        val text: TextView = view
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_file_tab, parent, false) as TextView
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val name = items[position]
        holder.text.text = name
        val isSelected = name == selected
        holder.text.isSelected = isSelected
        holder.text.setTextColor(
            ContextCompat.getColor(holder.itemView.context, if (isSelected) R.color.sata_on_primary else R.color.sata_text)
        )
        holder.itemView.setOnClickListener { onSelect(name) }
    }

    override fun getItemCount(): Int = items.size
}
