package com.zigsata.app

import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.zigsata.app.data.ProjectRepository
import com.zigsata.app.data.SettingsStore
import com.zigsata.app.editor.CodeEditText
import com.zigsata.app.editor.ZigSyntaxHighlighter
import com.zigsata.app.model.CompileError
import com.zigsata.app.network.CompileClient
import kotlinx.coroutines.launch
import java.io.IOException

class EditorActivity : AppCompatActivity() {

    private lateinit var repository: ProjectRepository
    private lateinit var settings: SettingsStore
    private lateinit var compileClient: CompileClient
    private lateinit var highlighter: ZigSyntaxHighlighter

    private lateinit var projectId: String
    private var currentFile: String? = null

    private lateinit var editCode: CodeEditText
    private lateinit var textLineNumbers: TextView
    private lateinit var textCursorPos: TextView
    private lateinit var textOutput: TextView
    private lateinit var progressCompiling: ProgressBar
    private lateinit var fileTabAdapter: FileTabAdapter

    private val mainHandler = Handler(Looper.getMainLooper())
    private var highlightRunnable: Runnable? = null
    private var autoSaveRunnable: Runnable? = null
    private var suppressWatcher = false

    private val importFileLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            uri?.let { importFile(it) }
        }
    private val exportFileLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri: Uri? ->
            uri?.let { exportCurrentFile(it) }
        }
    private val exportProjectLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri: Uri? ->
            uri?.let { exportProject(it) }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_editor)

        projectId = intent.getStringExtra(EXTRA_PROJECT_ID) ?: run { finish(); return }
        repository = ProjectRepository(this)
        settings = SettingsStore(this)
        compileClient = CompileClient(this)
        highlighter = ZigSyntaxHighlighter(this)

        val project = repository.getProject(projectId) ?: run {
            Toast.makeText(this, "Project not found", Toast.LENGTH_SHORT).show()
            finish(); return
        }

        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        toolbar.title = project.name
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener { finish() }

        editCode = findViewById(R.id.editCode)
        textLineNumbers = findViewById(R.id.textLineNumbers)
        textCursorPos = findViewById(R.id.textCursorPos)
        textOutput = findViewById(R.id.textOutput)
        progressCompiling = findViewById(R.id.progressCompiling)

        val recyclerFileTabs = findViewById<RecyclerView>(R.id.recyclerFileTabs)
        recyclerFileTabs.layoutManager = LinearLayoutManager(this, RecyclerView.HORIZONTAL, false)
        fileTabAdapter = FileTabAdapter { fileName -> switchToFile(fileName) }
        recyclerFileTabs.adapter = fileTabAdapter

        editCode.onSelectionChangedListener = { start, _ -> updateCursorPosition(start) }
        editCode.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (suppressWatcher) return
                updateLineNumbers()
                scheduleHighlight()
                scheduleAutoSave()
            }
        })

        findViewById<View>(R.id.buttonRun).setOnClickListener { runCode() }

        refreshFileList(preferredFile = project.mainFile)
    }

    override fun onPause() {
        super.onPause()
        saveCurrentFileNow()
    }

    // ---------- File tabs ----------

    private fun refreshFileList(preferredFile: String? = currentFile) {
        val files = repository.listFiles(projectId)
        if (files.isEmpty()) {
            currentFile = null
            editCode.setText("")
            return
        }
        val toOpen = preferredFile?.takeIf { files.contains(it) } ?: files.first()
        fileTabAdapter.submit(files, toOpen)
        switchToFile(toOpen)
    }

    private fun switchToFile(fileName: String) {
        saveCurrentFileNow()
        currentFile = fileName
        fileTabAdapter.setSelected(fileName)
        val content = try {
            repository.readFile(projectId, fileName)
        } catch (e: IOException) {
            Toast.makeText(this, getString(R.string.error_file_io, e.message ?: ""), Toast.LENGTH_SHORT).show()
            ""
        }
        suppressWatcher = true
        editCode.setText(content)
        editCode.setSelection(content.length.coerceAtMost(editCode.text?.length ?: 0))
        suppressWatcher = false
        updateLineNumbers()
        highlightNow()
    }

    // ---------- Editing: highlight, line numbers, cursor, autosave ----------

    private fun scheduleHighlight() {
        highlightRunnable?.let { mainHandler.removeCallbacks(it) }
        val runnable = Runnable { highlightNow() }
        highlightRunnable = runnable
        mainHandler.postDelayed(runnable, 250)
    }

    private fun highlightNow() {
        val editable = editCode.text ?: return
        highlighter.highlight(editable)
    }

    private fun updateLineNumbers() {
        val lineCount = (editCode.text?.toString() ?: "").count { it == '\n' } + 1
        val sb = StringBuilder()
        for (i in 1..lineCount) {
            sb.append(i)
            if (i != lineCount) sb.append('\n')
        }
        textLineNumbers.text = sb.toString()
    }

    private fun updateCursorPosition(cursor: Int) {
        val text = editCode.text?.toString() ?: return
        val safeCursor = cursor.coerceIn(0, text.length)
        val upToCursor = text.substring(0, safeCursor)
        val line = upToCursor.count { it == '\n' } + 1
        val col = safeCursor - (upToCursor.lastIndexOf('\n'))
        textCursorPos.text = "Ln $line, Col $col"
    }

    private fun scheduleAutoSave() {
        autoSaveRunnable?.let { mainHandler.removeCallbacks(it) }
        val runnable = Runnable { saveCurrentFileNow() }
        autoSaveRunnable = runnable
        mainHandler.postDelayed(runnable, 800)
    }

    private fun saveCurrentFileNow() {
        autoSaveRunnable?.let { mainHandler.removeCallbacks(it) }
        val file = currentFile ?: return
        val content = editCode.text?.toString() ?: return
        try {
            repository.writeFile(projectId, file, content)
        } catch (e: IOException) {
            Toast.makeText(this, getString(R.string.error_file_io, e.message ?: ""), Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- Run / compile ----------

    private fun runCode() {
        saveCurrentFileNow()
        val project = repository.getProject(projectId) ?: return
        val files = repository.listFiles(projectId)
        if (files.isEmpty()) {
            Toast.makeText(this, "Add a .zig file first", Toast.LENGTH_SHORT).show()
            return
        }
        val fileContents = files.map { name -> name to repository.readFile(projectId, name) }

        progressCompiling.visibility = View.VISIBLE
        textOutput.text = getString(R.string.compiling)

        lifecycleScope.launch {
            val outcome = compileClient.compile(
                serverUrl = settings.serverUrl,
                timeoutSeconds = settings.timeoutSeconds,
                mainFile = project.mainFile,
                files = fileContents
            )
            progressCompiling.visibility = View.GONE
            renderOutcome(outcome)
        }
    }

    private fun renderOutcome(outcome: CompileClient.Outcome) {
        when (outcome) {
            is CompileClient.Outcome.Success -> {
                val result = outcome.result
                val sb = StringBuilder()
                if (result.exitCode != null) {
                    sb.append(
                        if (result.success) getString(R.string.compile_success, result.exitCode)
                        else getString(R.string.compile_failed, result.exitCode)
                    ).append("\n\n")
                }
                if (result.stdout.isNotBlank()) sb.append("stdout:\n").append(result.stdout).append("\n\n")
                if (result.stderr.isNotBlank()) sb.append("stderr:\n").append(result.stderr).append("\n")
                if (result.diagnostics.isNotEmpty()) {
                    sb.append("\n").append(diagnosticsSummary(result))
                }
                textOutput.text = sb.toString().ifBlank { getString(R.string.no_output_yet) }
            }
            is CompileClient.Outcome.Failure -> {
                textOutput.text = messageForError(outcome.error)
            }
        }
    }

    private fun diagnosticsSummary(result: com.zigsata.app.model.CompileResult): String {
        return result.diagnostics.joinToString("\n") { d ->
            val loc = if (d.file != null && d.line != null) "${d.file}:${d.line}:${d.column ?: 0}" else "?"
            "[${d.severity}] $loc — ${d.message}"
        }
    }

    private fun messageForError(error: CompileError): String = when (error) {
        is CompileError.NoServerConfigured -> getString(R.string.error_no_server)
        is CompileError.NoInternet -> getString(R.string.error_no_internet)
        is CompileError.ServerUnreachable -> getString(R.string.error_server_unreachable)
        is CompileError.Timeout -> getString(R.string.error_timeout)
        is CompileError.InvalidResponse -> getString(R.string.error_invalid_response)
        is CompileError.Other -> error.detail
    }

    // ---------- File operations ----------

    private fun showNewFileDialog() {
        val input = EditText(this)
        input.hint = getString(R.string.file_name_hint)
        AlertDialog.Builder(this)
            .setTitle(R.string.new_file)
            .setView(input)
            .setPositiveButton(R.string.create) { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    try {
                        val created = repository.createFile(projectId, name)
                        refreshFileList(preferredFile = created)
                    } catch (e: IOException) {
                        Toast.makeText(this, e.message, Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun showRenameDialog() {
        val file = currentFile ?: return
        val input = EditText(this)
        input.setText(file)
        AlertDialog.Builder(this)
            .setTitle(R.string.rename_file)
            .setView(input)
            .setPositiveButton(R.string.save) { _, _ ->
                val newName = input.text.toString().trim()
                if (newName.isNotEmpty()) {
                    try {
                        saveCurrentFileNow()
                        val renamed = repository.renameFile(projectId, file, newName)
                        refreshFileList(preferredFile = renamed)
                    } catch (e: IOException) {
                        Toast.makeText(this, e.message, Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun confirmDeleteFile() {
        val file = currentFile ?: return
        AlertDialog.Builder(this)
            .setMessage("Delete $file?")
            .setPositiveButton(R.string.delete) { _, _ ->
                repository.deleteFile(projectId, file)
                refreshFileList(preferredFile = null)
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun setCurrentAsMain() {
        val file = currentFile ?: return
        repository.setMainFile(projectId, file)
        Toast.makeText(this, "$file is now the main file", Toast.LENGTH_SHORT).show()
    }

    private fun importFile(uri: Uri) {
        try {
            val name = queryDisplayName(uri)?.removeSuffix(".zig") ?: "imported"
            val imported = contentResolver.openInputStream(uri)?.use { input ->
                repository.importFile(projectId, input, name)
            }
            refreshFileList(preferredFile = imported)
        } catch (e: Exception) {
            Toast.makeText(this, getString(R.string.error_file_io, e.message ?: ""), Toast.LENGTH_LONG).show()
        }
    }

    private fun exportCurrentFile(uri: Uri) {
        val file = currentFile ?: return
        try {
            saveCurrentFileNow()
            contentResolver.openOutputStream(uri)?.use { out ->
                out.write(repository.readFile(projectId, file).toByteArray())
            }
            Toast.makeText(this, "Exported $file", Toast.LENGTH_SHORT).show()
        } catch (e: IOException) {
            Toast.makeText(this, getString(R.string.error_file_io, e.message ?: ""), Toast.LENGTH_LONG).show()
        }
    }

    private fun exportProject(uri: Uri) {
        try {
            saveCurrentFileNow()
            contentResolver.openOutputStream(uri)?.use { out -> repository.exportProjectZip(projectId, out) }
            Toast.makeText(this, "Project exported", Toast.LENGTH_SHORT).show()
        } catch (e: IOException) {
            Toast.makeText(this, getString(R.string.error_file_io, e.message ?: ""), Toast.LENGTH_LONG).show()
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        return try {
            contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (cursor.moveToFirst() && idx >= 0) cursor.getString(idx) else null
            }
        } catch (e: Exception) {
            null
        }
    }

    // ---------- Menu ----------

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_editor, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_new_file -> { showNewFileDialog(); true }
            R.id.action_import_file -> { importFileLauncher.launch(arrayOf("text/plain", "application/octet-stream", "*/*")); true }
            R.id.action_export_file -> {
                exportFileLauncher.launch(currentFile ?: "file.zig")
                true
            }
            R.id.action_export_project -> {
                val project = repository.getProject(projectId)
                exportProjectLauncher.launch("${project?.name ?: "project"}.zip")
                true
            }
            R.id.action_rename_file -> { showRenameDialog(); true }
            R.id.action_set_main -> { setCurrentAsMain(); true }
            R.id.action_delete_file -> { confirmDeleteFile(); true }
            R.id.action_settings -> { startActivity(Intent(this, SettingsActivity::class.java)); true }
            else -> super.onOptionsItemSelected(item)
        }
    }

    companion object {
        const val EXTRA_PROJECT_ID = "extra_project_id"
    }
}
