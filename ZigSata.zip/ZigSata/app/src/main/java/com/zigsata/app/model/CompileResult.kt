package com.zigsata.app.model

/** A single diagnostic (error, note, or warning) parsed from compiler output. */
data class CompileDiagnostic(
    val file: String?,
    val line: Int?,
    val column: Int?,
    val severity: String, // "error", "note", "warning"
    val message: String
)

/** Result of a remote compile+run request. */
data class CompileResult(
    val success: Boolean,
    val exitCode: Int?,
    val stdout: String,
    val stderr: String,
    val diagnostics: List<CompileDiagnostic>
)

/** Represents the different ways a compile request can fail before we ever get a result. */
sealed class CompileError(val userMessage: String) {
    object NoServerConfigured : CompileError("no_server")
    object NoInternet : CompileError("no_internet")
    object ServerUnreachable : CompileError("server_unreachable")
    object Timeout : CompileError("timeout")
    data class InvalidResponse(val detail: String) : CompileError("invalid_response")
    data class Other(val detail: String) : CompileError("other")
}
