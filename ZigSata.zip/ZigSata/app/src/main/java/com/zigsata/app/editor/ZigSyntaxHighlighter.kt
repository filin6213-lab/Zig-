package com.zigsata.app.editor

import android.text.Editable
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import androidx.core.content.ContextCompat
import android.content.Context
import com.zigsata.app.R
import java.util.regex.Pattern

/**
 * Lightweight regex tokenizer for Zig source. This is not a full parser -
 * it is intentionally simple and fast so it can run on every keystroke
 * (debounced) without a heavy dependency or native parser.
 */
class ZigSyntaxHighlighter(context: Context) {

    private val keywordColor = ContextCompat.getColor(context, R.color.syn_keyword)
    private val typeColor = ContextCompat.getColor(context, R.color.syn_type)
    private val stringColor = ContextCompat.getColor(context, R.color.syn_string)
    private val commentColor = ContextCompat.getColor(context, R.color.syn_comment)
    private val numberColor = ContextCompat.getColor(context, R.color.syn_number)
    private val functionColor = ContextCompat.getColor(context, R.color.syn_function)

    fun highlight(editable: Editable) {
        // Remove any spans we previously applied, keep everything else untouched.
        editable.getSpans(0, editable.length, HighlightSpan::class.java).forEach { editable.removeSpan(it) }

        val text = editable.toString()

        applyPattern(editable, STRING_PATTERN, stringColor)
        applyPattern(editable, COMMENT_PATTERN, commentColor)
        applyPattern(editable, NUMBER_PATTERN, numberColor)
        applyPattern(editable, FUNCTION_CALL_PATTERN, functionColor, group = 1)
        applyPattern(editable, buildKeywordPattern(), keywordColor)
        applyPattern(editable, buildTypePattern(), typeColor)
    }

    private fun applyPattern(editable: Editable, pattern: Pattern, color: Int, group: Int = 0) {
        val matcher = pattern.matcher(editable)
        while (matcher.find()) {
            val start = matcher.start(group)
            val end = matcher.end(group)
            if (start in 0..editable.length && end in start..editable.length) {
                editable.setSpan(HighlightSpan(color), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
        }
    }

    /** Marker subclass so we can find + remove only spans we own. */
    private class HighlightSpan(color: Int) : ForegroundColorSpan(color)

    companion object {
        private val KEYWORDS = listOf(
            "const", "var", "fn", "pub", "return", "if", "else", "while", "for", "switch",
            "struct", "enum", "union", "error", "try", "catch", "defer", "errdefer",
            "comptime", "break", "continue", "orelse", "null", "undefined", "true", "false",
            "and", "or", "test", "import", "export", "extern", "packed", "align", "volatile",
            "async", "await", "suspend", "resume", "nosuspend", "inline", "noinline",
            "threadlocal", "linksection", "callconv", "unreachable", "asm", "opaque",
            "anyframe", "usingnamespace"
        )

        private val TYPES = listOf(
            "i8", "i16", "i32", "i64", "i128", "isize",
            "u8", "u16", "u32", "u64", "u128", "usize",
            "f16", "f32", "f64", "f80", "f128",
            "bool", "void", "noreturn", "type", "anyerror", "anytype", "anyopaque", "c_int",
            "c_uint", "c_long", "c_ulong", "c_longlong", "c_ulonglong", "c_char"
        )

        private fun buildKeywordPattern(): Pattern =
            Pattern.compile("\\b(${KEYWORDS.joinToString("|")})\\b")

        private fun buildTypePattern(): Pattern =
            Pattern.compile("\\b(${TYPES.joinToString("|")})\\b")

        // Zig strings: "..." and \\ multi-line strings (basic, no escape-aware parsing).
        private val STRING_PATTERN: Pattern = Pattern.compile("\"(?:\\\\.|[^\"\\\\])*\"|\\\\\\\\[^\n]*")

        private val COMMENT_PATTERN: Pattern = Pattern.compile("//[^\n]*")

        private val NUMBER_PATTERN: Pattern =
            Pattern.compile("\\b(0x[0-9a-fA-F_]+|0b[01_]+|0o[0-7_]+|\\d[\\d_]*(\\.[\\d_]+)?)\\b")

        // Highlights `name(` as a function call/definition, capturing just the name.
        private val FUNCTION_CALL_PATTERN: Pattern = Pattern.compile("\\b([a-zA-Z_][a-zA-Z0-9_]*)\\s*\\(")
    }
}
