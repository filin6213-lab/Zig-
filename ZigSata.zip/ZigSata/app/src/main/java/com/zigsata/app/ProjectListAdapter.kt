package com.zigsata.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.zigsata.app.model.Project
import java.text.DateFormat
import java.util.Date

class ProjectListAdapter(
    private val onOpen: (Project) -> Unit,
    private val onMenu: (Project, View) -> Unit
) : RecyclerView.Adapter<ProjectListAdapter.VH>() {

    private val items = mutableListOf<Project>()

    fun submit(newItems: List<Project>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val name: TextView = view.findViewById(R.id.textProjectName)
        val meta: TextView = view.findViewById(R.id.textProjectMeta)
        val menuButton: View = view.findViewById(R.id.buttonProjectMenu)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_project, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val project = items[position]
        holder.name.text = project.name
        val date = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(project.updatedAt))
        holder.meta.text = "Updated $date"
        holder.itemView.setOnClickListener { onOpen(project) }
        holder.menuButton.setOnClickListener { onMenu(project, it) }
    }

    override fun getItemCount(): Int = items.size
}
