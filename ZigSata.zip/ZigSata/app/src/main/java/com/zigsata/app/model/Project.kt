package com.zigsata.app.model

import org.json.JSONObject

/**
 * Metadata for a Zig Sata project. The actual source files live as plain
 * .zig files inside the project's folder; this object is persisted as
 * "project.json" in that same folder.
 */
data class Project(
    val id: String,
    var name: String,
    var mainFile: String,
    val createdAt: Long,
    var updatedAt: Long
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("mainFile", mainFile)
        put("createdAt", createdAt)
        put("updatedAt", updatedAt)
    }

    companion object {
        fun fromJson(json: JSONObject): Project = Project(
            id = json.getString("id"),
            name = json.getString("name"),
            mainFile = json.optString("mainFile", "main.zig"),
            createdAt = json.optLong("createdAt", System.currentTimeMillis()),
            updatedAt = json.optLong("updatedAt", System.currentTimeMillis())
        )
    }
}
