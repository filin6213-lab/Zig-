# Zig Sata — compile server

Android can't reasonably ship a full Zig toolchain and run native compilation
sandboxed on-device, so Zig Sata compiles/runs code by sending it to a small
HTTP server that has Zig installed. This folder is a reference
implementation of that server. You run it yourself — nothing is sent
anywhere unless you set a server URL in the app's Settings screen.

## Contract

```
POST /compile
Content-Type: application/json

{
  "main": "main.zig",
  "files": [
    { "name": "main.zig", "content": "const std = @import(\"std\");\n..." }
  ]
}
```

Response:

```json
{
  "success": true,
  "exitCode": 0,
  "stdout": "Hello from Zig Sata!\n",
  "stderr": ""
}
```

`GET /health` returns `{ "status": "ok", "zigVersion": "..." }` and is useful
for a quick sanity check after deploying.

## Running locally

```bash
cd server
npm install
ZIG_BIN=/path/to/zig node server.js
```

Or with Docker (bundles the Zig toolchain for you):

```bash
cd server
docker build -t zig-sata-server .
docker run --rm -p 3000:3000 zig-sata-server
```

Then in the app, open **Settings** and set the server URL:
- Android emulator talking to a server on your own machine: `http://10.0.2.2:3000`
- Physical device on the same Wi-Fi: `http://<your-computer-LAN-IP>:3000`
- A server you deployed publicly: its `https://` URL

## Security notes (read before exposing this publicly)

This server executes arbitrary user-submitted code (`zig run`). Treat every
request as hostile:

- Run it in an isolated container with **no outbound network access**
  (`docker run --network=none` after the image is built, or an equivalent
  firewall rule), so submitted code can't phone home or attack other hosts.
- Set CPU, memory, and process limits (e.g. `docker run --cpus=1 --memory=256m
  --pids-limit=64`).
- The server already enforces a compile/run timeout (`COMPILE_TIMEOUT_MS`,
  default 20s) and a total source-size cap, but you should still put it
  behind your own rate limiting and authentication if it's reachable from
  the internet.
- Prefer running one throwaway container per request (or a pool of
  short-lived sandboxes) over a single long-lived process in
  higher-stakes deployments.
- The reference implementation runs as a non-root user inside the
  container, but it is not a substitute for OS-level sandboxing (gVisor,
  Firecracker, etc.) if you plan to expose it beyond trusted/personal use.

## Environment variables

| Variable            | Default | Purpose                                   |
|---------------------|---------|--------------------------------------------|
| `PORT`               | `3000`  | HTTP port                                  |
| `ZIG_BIN`            | `zig`   | Path to the `zig` executable               |
| `COMPILE_TIMEOUT_MS` | `20000` | Kill the process after this many ms        |
