package com.zigsata.app

import android.os.Bundle
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.zigsata.app.data.SettingsStore

class SettingsActivity : AppCompatActivity() {

    private lateinit var settings: SettingsStore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        settings = SettingsStore(this)

        val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar)
        toolbar.title = getString(R.string.settings_title)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener { finish() }

        val editUrl = findViewById<EditText>(R.id.editServerUrl)
        val editTimeout = findViewById<EditText>(R.id.editTimeout)

        editUrl.setText(settings.serverUrl)
        editTimeout.setText(settings.timeoutSeconds.toString())

        findViewById<android.widget.Button>(R.id.buttonSaveSettings).setOnClickListener {
            settings.serverUrl = editUrl.text.toString()
            settings.timeoutSeconds = editTimeout.text.toString().toIntOrNull()?.coerceIn(5, 120) ?: 20
            Toast.makeText(this, R.string.settings_saved, Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
