package com.zigsata.app

import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import android.widget.PopupMenu
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.zigsata.app.data.ProjectRepository
import com.zigsata.app.model.Project
import java.io.IOException

class MainActivity : AppCompatActivity() {

    private lateinit var repository: ProjectRepository
    private lateinit var adapter: ProjectListAdapter
    private lateinit var recyclerView: RecyclerView
    private lateinit var emptyView: View

    private val importProjectLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            uri?.let { importProject(it) }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        repository = ProjectRepository(this)

        setSupportActionBar(findViewById(R.id.toolbar))

        recyclerView = findViewById(R.id.recyclerProjects)
        emptyView = findViewById(R.id.emptyView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = ProjectListAdapter(
            onOpen = { project -> openProject(project) },
            onMenu = { project, anchor -> showProjectMenu(project, anchor) }
        )
        recyclerView.adapter = adapter

        findViewById<View>(R.id.fabNewProject).setOnClickListener { showCreateProjectDialog() }
    }

    override fun onResume() {
        super.onResume()
        refreshList()
    }

    private fun refreshList() {
        val projects = repository.listProjects()
        adapter.submit(projects)
        emptyView.visibility = if (projects.isEmpty()) View.VISIBLE else View.GONE
        recyclerView.visibility = if (projects.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun openProject(project: Project) {
        val intent = Intent(this, EditorActivity::class.java)
        intent.putExtra(EditorActivity.EXTRA_PROJECT_ID, project.id)
        startActivity(intent)
    }

    private fun showCreateProjectDialog() {
        val input = EditText(this)
        input.hint = getString(R.string.project_name_hint)
        AlertDialog.Builder(this)
            .setTitle(R.string.new_project)
            .setView(input)
            .setPositiveButton(R.string.create) { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    val project = repository.createProject(name)
                    refreshList()
                    openProject(project)
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun showProjectMenu(project: Project, anchor: View) {
        val popup = PopupMenu(this, anchor)
        popup.menu.add(0, 1, 0, R.string.export)
        popup.menu.add(0, 2, 1, R.string.delete)
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> { exportProject(project); true }
                2 -> { confirmDeleteProject(project); true }
                else -> false
            }
        }
        popup.show()
    }

    private fun confirmDeleteProject(project: Project) {
        AlertDialog.Builder(this)
            .setMessage(R.string.delete_project_confirm)
            .setPositiveButton(R.string.delete) { _, _ ->
                repository.deleteProject(project.id)
                refreshList()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private val exportTargetProject = mutableMapOf<String, Project>()

    private fun exportProject(project: Project) {
        exportTargetProject["pending"] = project
        exportProjectLauncher.launch("${project.name}.zip")
    }

    private val exportProjectLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri: Uri? ->
            val project = exportTargetProject.remove("pending") ?: return@registerForActivityResult
            if (uri == null) return@registerForActivityResult
            try {
                contentResolver.openOutputStream(uri)?.use { out ->
                    repository.exportProjectZip(project.id, out)
                }
                Toast.makeText(this, "Exported ${project.name}.zip", Toast.LENGTH_SHORT).show()
            } catch (e: IOException) {
                Toast.makeText(this, getString(R.string.error_file_io, e.message ?: ""), Toast.LENGTH_LONG).show()
            }
        }

    private fun importProject(uri: Uri) {
        try {
            val name = queryDisplayName(uri)?.removeSuffix(".zip") ?: "imported_project"
            contentResolver.openInputStream(uri)?.use { input ->
                repository.importProjectZip(input, name)
            }
            refreshList()
            Toast.makeText(this, "Imported $name", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, getString(R.string.error_file_io, e.message ?: ""), Toast.LENGTH_LONG).show()
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        return try {
            contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (cursor.moveToFirst() && nameIndex >= 0) cursor.getString(nameIndex) else null
            }
        } catch (e: Exception) {
            null
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_import_project -> {
                importProjectLauncher.launch(arrayOf("application/zip", "application/octet-stream"))
                true
            }
            R.id.action_settings -> {
                startActivity(Intent(this, SettingsActivity::class.java))
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
