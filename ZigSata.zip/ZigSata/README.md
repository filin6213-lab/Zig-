# Zig Sata

> Sata — because sata is faster than ide.

A lightweight Zig development environment for Android: create and edit
`.zig` files and projects, get syntax highlighting, run/compile your code,
and see stdout/stderr/compiler errors — all from your phone, no Termux or
other third-party app required.

## Features

- Create, open, edit, and save `.zig` files
- Create and store multiple Zig projects, each with multiple source files
- Zig syntax highlighting (keywords, types, strings, comments, numbers)
- Automatic saving as you type (debounced, no manual save required)
- Import/export single files and whole projects (as `.zip`) via the system
  file picker
- Run/compile Zig code and see stdout, stderr, and compiler diagnostics
  with file/line/column information
- Clear, specific error handling for compile errors, runtime errors, no
  internet connection, and file I/O problems
- Projects persist across app restarts (private app storage, no special
  permissions needed)
- Works fully offline for editing; only "Run" needs a network connection

## Why a server component?

A real Zig toolchain (compiler + standard library + linker) is large and
not something that installs or runs well as a native Android library.
Rather than faking compilation or bundling a half-working toolchain, Zig
Sata sends your project to a small compile server (that you host — see
[`/server`](server)) which runs `zig run` and streams back stdout, stderr,
and the exit code. The app handles "no server configured," "no internet,"
and "server unreachable" as distinct, clearly-messaged states rather than
generic failures.

This keeps the Android app itself small, dependency-light, and stable,
while still supporting the latest Zig releases — upgrading Zig is just
upgrading the server, no app update required.

## Project layout

```
ZigSata/
├── app/                     Android app (Kotlin)
│   └── src/main/java/com/zigsata/app/
│       ├── MainActivity.kt        Project list
│       ├── EditorActivity.kt      Editor, file tabs, run/compile
│       ├── SettingsActivity.kt    Compile server configuration
│       ├── model/                 Project, CompileResult, diagnostics
│       ├── data/                  ProjectRepository, SettingsStore
│       ├── editor/                Syntax highlighter, CodeEditText
│       ├── network/               CompileClient (OkHttp + coroutines)
│       └── util/                  Zip, error parsing, connectivity
├── server/                  Reference remote compile server (Node.js)
├── .github/workflows/       CI: build, test, lint, upload APK artifact
└── build.gradle.kts, settings.gradle.kts, ...
```

## Building the app

1. Open the `ZigSata/` folder in Android Studio (Koala or newer). It will
   generate the Gradle wrapper automatically on first sync.
   - Building from the command line instead: run `gradle wrapper` once
     (requires a local Gradle install) to generate `gradlew`, then use
     `./gradlew assembleDebug`.
2. Build → make the `debug` build variant, or run `assembleDebug`. The
   resulting APK installs on any device/emulator with API 26+.
3. Before using **Run**, start a compile server (see
   [`server/README.md`](server/README.md)) and set its URL in the app's
   Settings screen.

## Continuous integration

`.github/workflows/android.yml` runs on every push/PR:

1. checks out the repo and sets up JDK 17, the Android SDK, and Gradle
2. runs unit tests (`testDebugUnitTest`)
3. runs lint (`lintDebug`)
4. builds a debug APK (`assembleDebug`)
5. uploads the APK, lint report, and test report as workflow artifacts

Download the APK from the run's **Artifacts** section — no signing
configuration is required for the debug build.

## Known limitations / next steps

- Compilation requires a network connection and a self-hosted server;
  there is no offline/on-device compilation.
- The code editor uses regex-based highlighting (fast, dependency-free)
  rather than a full Zig parser, so highlighting inside nested strings/
  comments is best-effort, not 100% accurate.
- No autocomplete or LSP integration yet — a natural next step would be
  running `zls` (Zig Language Server) alongside the compile server and
  proxying requests to it.
- No code signing / release build configuration is included; add a
  signing config before publishing a release build.

## License

MIT — see [LICENSE](LICENSE).
