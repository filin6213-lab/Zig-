package com.zigsata.app.util

import com.zigsata.app.model.CompileDiagnostic
import java.util.regex.Pattern

/**
 * Zig's compiler emits diagnostics in the form:
 *   <file>:<line>:<column>: error: <message>
 *   <file>:<line>:<column>: note: <message>
 * This parser pulls those out so the UI can show file/line/column and let
 * the user jump straight to the offending line.
 */
object ErrorParser {

    private val DIAGNOSTIC_PATTERN: Pattern =
        Pattern.compile("^(.*?):(\\d+):(\\d+):\\s*(error|note|warning):\\s*(.*)$")

    fun parse(output: String): List<CompileDiagnostic> {
        if (output.isBlank()) return emptyList()
        val diagnostics = mutableListOf<CompileDiagnostic>()
        for (rawLine in output.lineSequence()) {
            val matcher = DIAGNOSTIC_PATTERN.matcher(rawLine.trim())
            if (matcher.matches()) {
                diagnostics.add(
                    CompileDiagnostic(
                        file = matcher.group(1),
                        line = matcher.group(2)?.toIntOrNull(),
                        column = matcher.group(3)?.toIntOrNull(),
                        severity = matcher.group(4) ?: "error",
                        message = matcher.group(5) ?: rawLine
                    )
                )
            }
        }
        return diagnostics
    }
}
